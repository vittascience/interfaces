@echo Find a drive that has a folder titled Images.
@for %%a in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do @if exist %%a:DETAILS.txt set IMAGESDRIVE=%%a
@echo The drive is: %IMAGESDRIVE%:
@robocopy . %IMAGESDRIVE%: firmware_micropython1.19.bin /z
pause